package com.webapps2022.thrift;

import org.apache.thrift.TException;

public class TransactionTimestampHandler implements TransactionTimestampService.Iface {

    @Override
    public long transactionTimestamp() throws TException {
        long dateTime = System.currentTimeMillis();
        return dateTime;
    }

}
