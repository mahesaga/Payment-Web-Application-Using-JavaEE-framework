package com.webapps2022.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("conversion")
public class RSConversionApplication extends Application {

}
