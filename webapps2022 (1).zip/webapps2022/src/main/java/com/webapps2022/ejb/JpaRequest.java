package com.webapps2022.ejb;

import com.webapps2022.entity.Request;
import java.util.List;
public interface JpaRequest extends Dao<Request> {

    List<Request> findRequestsByUsernameTo(String username);

}
