package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUser;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;

@Stateless
@TransactionAttribute(REQUIRED)
public class JpaSystemUserImpl extends DaoImpl<SystemUser> implements JpaSystemUser {

    @Override
    public List<SystemUser> findAllSystemUsers()//Functin returns all th system userss present in the system
    {
        return em.createNamedQuery("findAllSystemUsers").getResultList();

    }

    @Override
    public SystemUser findSystemUserByUsername(String username)//Function returns user for the given username
    {
        List<SystemUser> systemUsers = em.createNamedQuery("findSystemUserByUsername").setParameter("username", username).getResultList();

        if (systemUsers.isEmpty()) {
            return null;
        }

        return systemUsers.get(0);
    }

    @Override
    public void registerSystemUser(SystemUser systemUser)//function used for encrypting password and stores user in the database
    {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String pw = systemUser.getUserpassword();
            md.update(pw.getBytes("UTF-8"));
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < digest.length; i++) {
                sb.append(Integer.toString((digest[i] & 0xff) + 0x100, 16).substring(1));
            }
            String passwordDB = sb.toString();
            systemUser.setUserpassword(passwordDB);
            em.persist(systemUser);
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
            Logger.getLogger(JpaSystemUser.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void update(SystemUser systemUser) {
        em.merge(systemUser);
    }

}
