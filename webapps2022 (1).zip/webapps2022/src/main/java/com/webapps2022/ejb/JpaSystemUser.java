package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUser;
import java.util.List;

public interface JpaSystemUser extends Dao<SystemUser> {

    List<SystemUser> findAllSystemUsers();

    SystemUser findSystemUserByUsername(String username);

    void registerSystemUser(SystemUser systemUser);

    void update(SystemUser systemUser);

}
