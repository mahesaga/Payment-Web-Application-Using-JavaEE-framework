package com.webapps2022.ejb;

public interface Dao<T> {

    void persist(T entity);

    void remove(T entity);

    T findById(Long id);

}
