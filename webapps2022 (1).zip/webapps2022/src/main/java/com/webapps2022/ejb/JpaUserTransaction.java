package com.webapps2022.ejb;

import com.webapps2022.entity.UserTransaction;
import java.math.BigDecimal;
import java.util.List;

public interface JpaUserTransaction extends Dao<UserTransaction> {

    void persistWithTimestamp(UserTransaction entity);

    BigDecimal getCurrencyConversion(String currencyFrom, String currencyTo, BigDecimal amount);

    List<UserTransaction> findUserTransactionsByUsername(String username);
}
