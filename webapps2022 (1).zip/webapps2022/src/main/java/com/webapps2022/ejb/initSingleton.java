package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.SystemUserGroup;
import java.math.BigDecimal;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Startup
@Singleton
public class initSingleton {

    @Inject
    JpaSystemUser systemUserDao;
    @Inject
    JpaSystemUserGroup systemUserGroupDao;
    
    @PostConstruct
    public void init() {
//it is for geneating default admin user in th system
        if (systemUserDao.findSystemUserByUsername("admin1") == null) {
            SystemUser newSystemUser = new SystemUser("admin1@admin1.com", "admin1", "admin1", "admin1", "admin1", new BigDecimal(1000), "GBP");
            SystemUserGroup newSystemUserGroup = new SystemUserGroup("admin1", "admins");

            systemUserDao.registerSystemUser(newSystemUser);
            systemUserGroupDao.persist(newSystemUserGroup);
        }
    }

   
}
