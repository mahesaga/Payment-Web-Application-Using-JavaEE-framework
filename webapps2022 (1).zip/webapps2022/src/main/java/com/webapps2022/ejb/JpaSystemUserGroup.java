package com.webapps2022.ejb;

import com.webapps2022.entity.SystemUserGroup;
public interface JpaSystemUserGroup extends Dao<SystemUserGroup> {

}
