package com.webapps2022.ejb;

import com.webapps2022.entity.Request;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import static javax.ejb.TransactionAttributeType.REQUIRED;

@Stateless
@TransactionAttribute(REQUIRED)
public class JpaRequestImpl extends DaoImpl<Request> implements JpaRequest {

    @Override
    public List<Request> findRequestsByUsernameTo(String username)//Function returns all the requests for the given username
    {
        return em.createNamedQuery("findRequestsByUsernameTo").setParameter("username", username).getResultList();
    }

}
