package com.webapps2022.jsf;

public enum Currency//Enumerated data type to store currency
{
    GBP, EUR, USD
}
