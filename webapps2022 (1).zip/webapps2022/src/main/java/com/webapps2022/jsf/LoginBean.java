package com.webapps2022.jsf;

import java.io.Serializable;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

@Named(value = "loginBean")
@RequestScoped
public class LoginBean implements Serializable//It has login configuration
{

    public LoginBean() {

    }

    public String logout()//It logouts users from the system
    {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) facesContext.getExternalContext().getRequest();
        try {
            request.logout();
            facesContext.addMessage(null, new FacesMessage("User is logged out"));
            return "index";
        } catch (ServletException e) {
            facesContext.addMessage(null, new FacesMessage("Logout failed."));
        }
        return null;
    }

}
