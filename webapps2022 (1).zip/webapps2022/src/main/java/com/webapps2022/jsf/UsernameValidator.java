package com.webapps2022.jsf;

import com.webapps2022.ejb.JpaSystemUser;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.inject.Named;
@Named(value = "usernameValidator")
@RequestScoped
public class UsernameValidator implements Validator {

    @EJB
    JpaSystemUser systemUser;

    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {

        if (systemUser.findSystemUserByUsername(value.toString()) != null) {
            throw new ValidatorException(new FacesMessage("Username already exists"));
        }
    }

    public JpaSystemUser getSystemUserDao() {
        return systemUser;
    }

    public void setSystemUserDao(JpaSystemUser systemUserDao) {
        this.systemUser = systemUserDao;
    }

    
}
