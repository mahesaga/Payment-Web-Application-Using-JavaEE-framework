package com.webapps2022.jsf;

import com.webapps2022.ejb.JpaSystemUser;
import com.webapps2022.ejb.JpaUserTransaction;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.UserTransaction;
import java.math.BigDecimal;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@Named(value = "userMakePaymentBean")
@RequestScoped
public class UserMakePaymentBean {

    @EJB
    JpaSystemUser systemUser;

    @EJB
    JpaUserTransaction userTransaction;

    private String userNameTo;
    private BigDecimal amount;

    public UserMakePaymentBean() {
    }

    public String getUserNameTo() {
        return userNameTo;
    }

    public void setUserNameTo(String userNameTo) {
        this.userNameTo = userNameTo;
    }

    @RolesAllowed("users")
    public List<SystemUser> getUserList()//This returns all the users for transactions and delete the current user
    {
        SystemUser currentUser = getLoggedInUser();

        List<SystemUser> users = systemUser.findAllSystemUsers();
        users.remove(currentUser);

        return users;
    }

    @RolesAllowed("users")
    public SystemUser getLoggedInUser()//This returns current logged in username
    {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getRemoteUser();

        String currentUserUsername = context.getExternalContext().getRemoteUser();

        SystemUser currentUser = systemUser.findSystemUserByUsername(currentUserUsername);

        return currentUser;
    }

    @RolesAllowed("users")
    public void makePayment() {
        SystemUser from = getLoggedInUser();
        SystemUser to = systemUser.findSystemUserByUsername(userNameTo);

        BigDecimal convertedAmount = userTransaction.getCurrencyConversion(from.getCurrency(), to.getCurrency(), amount);

        BigDecimal fromNewBalance = from.getBalance().subtract(amount);
        BigDecimal toNewBalance = to.getBalance().add(convertedAmount);

        from.setBalance(fromNewBalance);
        to.setBalance(toNewBalance);

        UserTransaction transaction = new UserTransaction(from.getUsername(), to.getUsername(), from.getCurrency(), to.getCurrency(), amount, convertedAmount);

        systemUser.update(from);
        systemUser.update(to);
        userTransaction.persistWithTimestamp(transaction);

    }

    @RolesAllowed("users")
    public JpaSystemUser getSystemUserDao() {
        return systemUser;
    }

    @RolesAllowed("users")
    public void setSystemUserDao(JpaSystemUser systemUserDao) {
        this.systemUser= systemUserDao;
    }

    @RolesAllowed("users")
    public JpaUserTransaction getUserTransactionDao() {
        return userTransaction;
    }

    @RolesAllowed("users")
    public void setUserTransactionDao(JpaUserTransaction userTransactionDao) {
        this.userTransaction= userTransactionDao;
    }

    @RolesAllowed("users")
    public BigDecimal getAmount() {
        return amount;
    }

    @RolesAllowed("users")
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

}
