package com.webapps2022.jsf;

import com.webapps2022.entity.Request;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.UserTransaction;
import java.math.BigDecimal;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import com.webapps2022.ejb.JpaRequest;
import com.webapps2022.ejb.JpaSystemUser;
import com.webapps2022.ejb.JpaUserTransaction;

@Named(value = "userRequestBean")
@RequestScoped
public class UserRequestBean {

    @EJB
    JpaSystemUser systemUser;

    @EJB
    JpaUserTransaction userTransaction;

    @EJB
    JpaRequest requestDao;

    private String userName;
    private BigDecimal amount;

    public UserRequestBean() {
    }

    @RolesAllowed("users")
    public void createRequest()//Function for creating user request
    {
        SystemUser currentUser = getLoggedInUser();
        SystemUser toUser = systemUser.findSystemUserByUsername(userName);

        FacesContext facesContext = FacesContext.getCurrentInstance();

        BigDecimal convertedAmount = userTransaction.getCurrencyConversion(currentUser.getCurrency(), toUser.getCurrency(), amount);

        Request request = new Request(currentUser.getUsername(), toUser.getUsername(), convertedAmount);

        requestDao.persist(request);
        facesContext.addMessage(null, new FacesMessage("Request Sent"));

    }

    @RolesAllowed("users")
    public List<Request> getUserRequests()//returnss list of user requests
    {
        SystemUser currentUser = getLoggedInUser();
        return requestDao.findRequestsByUsernameTo(currentUser.getUsername());
    }

    @RolesAllowed("users")
    public void acceptRequest(Request request, boolean accepted)//Functions for accepting user requests
    {
        SystemUser fromUser = systemUser.findSystemUserByUsername(request.getUsernameFrom());
        SystemUser toUser = systemUser.findSystemUserByUsername(request.getUsernameTo());

        FacesContext facesContext = FacesContext.getCurrentInstance();

        if (accepted) {
            if (toUser.getBalance().compareTo(request.getAmount()) >= 0) {
                makePayment(toUser, fromUser, request.getAmount());

                requestDao.remove(request);
                facesContext.addMessage(null, new FacesMessage("Payment Made"));

            } else {
                facesContext.addMessage(null, new FacesMessage("Balance is too low"));
            }
        } else {
            requestDao.remove(request);
            facesContext.addMessage(null, new FacesMessage("Request Declined"));
        }
    }

    @RolesAllowed("users")
    public void makePayment(SystemUser from, SystemUser to, BigDecimal amount)//Functions for makin payments 
    {
        BigDecimal convertedAmount = userTransaction.getCurrencyConversion(from.getCurrency(), to.getCurrency(), amount);

        BigDecimal fromNewBalance = from.getBalance().subtract(amount);
        BigDecimal toNewBalance = to.getBalance().add(convertedAmount);

        from.setBalance(fromNewBalance);
        to.setBalance(toNewBalance);

        UserTransaction transaction = new UserTransaction(from.getUsername(), to.getUsername(), from.getCurrency(), to.getCurrency(), amount, convertedAmount);

        systemUser.update(from);
        systemUser.update(to);
        userTransaction.persistWithTimestamp(transaction);
    }

    @RolesAllowed("users")
    public SystemUser getLoggedInUser() {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getRemoteUser();

        String currentUserUsername = context.getExternalContext().getRemoteUser();

        SystemUser currentUser = systemUser.findSystemUserByUsername(currentUserUsername);

        return currentUser;
    }

    @RolesAllowed("users")
    public JpaSystemUser getSystemUserDao() {
        return systemUser;
    }

    @RolesAllowed("users")
    public void setSystemUserDao(JpaSystemUser systemUserDao) {
        this.systemUser = systemUserDao;
    }

    @RolesAllowed("users")
    public JpaUserTransaction getUserTransactionDao() {
        return userTransaction;
    }

    @RolesAllowed("users")
    public void setUserTransactionDao(JpaUserTransaction userTransactionDao) {
        this.userTransaction = userTransactionDao;
    }

    @RolesAllowed("users")
    public JpaRequest getRequestDao() {
        return requestDao;
    }

    @RolesAllowed("users")
    public void setRequestDao(JpaRequest requestDao) {
        this.requestDao = requestDao;
    }

    @RolesAllowed("users")
    public String getUserName() {
        return userName;
    }

    @RolesAllowed("users")
    public void setUserName(String userName) {
        this.userName = userName;
    }

    @RolesAllowed("users")
    public BigDecimal getAmount() {
        return amount;
    }

    @RolesAllowed("users")
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    
}
