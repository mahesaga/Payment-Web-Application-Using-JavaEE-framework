package com.webapps2022.jsf;

import com.webapps2022.ejb.JpaSystemUser;
import com.webapps2022.ejb.JpaUserTransaction;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.UserTransaction;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
@Named(value = "userTransactionsBean")
@RequestScoped
public class UserTransactionsBean {

    @EJB
    JpaSystemUser systemUserDao;

    @EJB
    JpaUserTransaction userTransactionDao;

    public UserTransactionsBean() {
    }

    @RolesAllowed("users")
    public List<UserTransaction> getTransactions() //This returns user transactons
    {
        SystemUser currentUser = getLoggedInUser();
        List<UserTransaction> transactions = userTransactionDao.findUserTransactionsByUsername(currentUser.getUsername());

        return transactions;
    }

    @RolesAllowed("users")
    public SystemUser getLoggedInUser()//This returns current logged in username
    {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getExternalContext().getRemoteUser();

        String currentUserUsername = context.getExternalContext().getRemoteUser();

        SystemUser currentUser = systemUserDao.findSystemUserByUsername(currentUserUsername);

        return currentUser;
    }

    @RolesAllowed("users")
    public JpaSystemUser getSystemUserDao() {
        return systemUserDao;
    }

    @RolesAllowed("users")
    public void setSystemUserDao(JpaSystemUser systemUserDao) {
        this.systemUserDao = systemUserDao;
    }

    @RolesAllowed("users")
    public JpaUserTransaction getUserTransactionDao() {
        return userTransactionDao;
    }

    @RolesAllowed("users")
    public void setUserTransactionDao(JpaUserTransaction userTransactionDao) {
        this.userTransactionDao = userTransactionDao;
    }

    
}
