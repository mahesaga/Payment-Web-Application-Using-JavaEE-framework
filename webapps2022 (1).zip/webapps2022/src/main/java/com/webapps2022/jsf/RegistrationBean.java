package com.webapps2022.jsf;

import com.webapps2022.ejb.JpaSystemUser;
import com.webapps2022.ejb.JpaSystemUserGroup;
import com.webapps2022.ejb.JpaUserTransaction;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.SystemUserGroup;
import java.io.Serializable;
import java.math.BigDecimal;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
@Named(value = "registrationBean")
@RequestScoped
public class RegistrationBean implements Serializable {

    @EJB
    JpaSystemUser systemUser;

    @EJB
    JpaSystemUserGroup systemUserGroup;

    @EJB
    JpaUserTransaction userTransaction;

    Currency[] currencies = Currency.values();

    String email;
    String firstName;
    String surname;
    String username;
    String password;
    String currency;

    public RegistrationBean() {
    }

    public String registerUser()//Fnction  used to set user details such as username,password, balance an currency
    {
        BigDecimal balance = userTransaction.getCurrencyConversion("GBP", currency, new BigDecimal(1000));

        SystemUser newUser = new SystemUser(email, firstName, surname, username, password, balance, currency);
        SystemUserGroup newUserGroup = new SystemUserGroup(username, "users");

        systemUser.registerSystemUser(newUser);
        systemUserGroup.persist(newUserGroup);

        return "index";
    }

    public String registerAdmin()//Fnction  used to set admin details such as username,password, balance an currency
    {
        BigDecimal balance = userTransaction.getCurrencyConversion("GBP", currency, new BigDecimal(1000));

        SystemUser newUser = new SystemUser(email, firstName, surname, username, password, balance, currency);
        SystemUserGroup newUserGroup = new SystemUserGroup(username, "admins");

        systemUser.registerSystemUser(newUser);
        systemUserGroup.persist(newUserGroup);

        return "admin";
    }

    public JpaSystemUser getSystemUserDao() {
        return systemUser;
    }

    public void setSystemUserDao(JpaSystemUser systemUserDao) {
        this.systemUser = systemUserDao;
    }

    public JpaSystemUserGroup getSystemUserGroupDao() {
        return systemUserGroup;
    }

    public void setSystemUserGroupDao(JpaSystemUserGroup systemUserGroupDao) {
        this.systemUserGroup = systemUserGroupDao;
    }

    public JpaUserTransaction getUserTransactionDao() {
        return userTransaction;
    }

    public void setUserTransactionDao(JpaUserTransaction userTransactionDao) {
        this.userTransaction = userTransactionDao;
    }

    public Currency[] getCurrencies() {
        return currencies;
    }

    public void setCurrencies(Currency[] currencies) {
        this.currencies = currencies;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    
}
