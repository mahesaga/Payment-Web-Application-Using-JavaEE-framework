package com.webapps2022.jsf;
import com.webapps2022.ejb.JpaSystemUser;
import com.webapps2022.ejb.JpaUserTransaction;
import com.webapps2022.entity.SystemUser;
import com.webapps2022.entity.UserTransaction;
import java.math.BigDecimal;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named(value = "adminUserAccountsBean")
@RequestScoped 
public class AdminUserAccountsBean//This is used for admin functions for setting balance and retriving transactions
{

    @EJB
    JpaSystemUser systemUserDao;

    @EJB
    JpaUserTransaction userTransaction;

    private String userName;
    private SystemUser systemUser;

    public AdminUserAccountsBean() {
    }

    @RolesAllowed("admins")
    public void setSelectedUser() {
        systemUser = systemUserDao.findSystemUserByUsername(userName);
    }

    @RolesAllowed("admins")
    public List<SystemUser> getUserList() {
        return systemUserDao.findAllSystemUsers();
    }

    @RolesAllowed("admins")
    public BigDecimal getUsersBalance() {
        if (systemUser != null) {
            return systemUser.getBalance();
        }
        return null;
    }

    @RolesAllowed("admins")
    public List<UserTransaction> getUserTransactions()//tnis is disply user transcaion
    {
        if (systemUser != null) {
            return userTransaction.findUserTransactionsByUsername(userName);
        }
        return null;
    }

    @RolesAllowed("admins")//onl admin can accses this function
    public JpaSystemUser getSystemUserDao() {
        return systemUserDao;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public void setSystemUserDao(JpaSystemUser systemUserDao) {
        this.systemUserDao = systemUserDao;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public JpaUserTransaction getUserTransaction() {
        return userTransaction;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public void setUserTransaction(JpaUserTransaction userTransaction) {
        this.userTransaction = userTransaction;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public String getUserName() {
        return userName;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public void setUserName(String userName) {
        this.userName = userName;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public SystemUser getSystemUser() {
        return systemUser;
    }

    @RolesAllowed("admins")//only admin can accses this function
    public void setSystemUser(SystemUser systemUser) {
        this.systemUser = systemUser;
    }

    
}
