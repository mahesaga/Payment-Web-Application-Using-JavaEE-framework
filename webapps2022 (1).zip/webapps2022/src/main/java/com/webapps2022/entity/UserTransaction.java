package com.webapps2022.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
    @NamedQuery(name = "findUserTransactionsByUsername", query = "SELECT t FROM UserTransaction t WHERE t.usernameFrom=:username OR t.usernameTo=:username")
@Entity
public class UserTransaction implements Serializable//Entity for storing user transaction details
    {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String usernameFrom;
    private String usernameTo;
    private String currencyFrom;
    private String currencyTo;
    @Column(precision = 12, scale = 2)
    private BigDecimal amountFrom;
    @Column(precision = 12, scale = 2)
    private BigDecimal amountTo;

    @Temporal(TemporalType.TIMESTAMP)
    private Date transactionTimestamp;

    public UserTransaction() {
    }

    public UserTransaction(String usernameFrom, String usernameTo, String currencyFrom, String currencyTo, BigDecimal amountFrom, BigDecimal amountTo) {
        this.usernameFrom = usernameFrom;
        this.usernameTo = usernameTo;
        this.currencyFrom = currencyFrom;
        this.currencyTo = currencyTo;
        this.amountFrom = amountFrom;
        this.amountTo = amountTo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getAmountFrom() {
        return amountFrom;
    }

    public void setAmountFrom(BigDecimal amountFrom) {
        this.amountFrom = amountFrom.setScale(2, RoundingMode.FLOOR);
    }

    public String getUsernameFrom() {
        return usernameFrom;
    }

    public void setUsernameFrom(String usernameFrom) {
        this.usernameFrom = usernameFrom;
    }

    public String getUsernameTo() {
        return usernameTo;
    }

    public void setUsernameTo(String usernameTo) {
        this.usernameTo = usernameTo;
    }

    public BigDecimal getAmountTo() {
        return amountTo;
    }

    public void setAmountTo(BigDecimal amountTo) {
        this.amountTo = amountTo;
    }

    public String getCurrencyFrom() {
        return currencyFrom;
    }

    public void setCurrencyFrom(String currencyFrom) {
        this.currencyFrom = currencyFrom;
    }

    public String getCurrencyTo() {
        return currencyTo;
    }

    public void setCurrencyTo(String currencyTo) {
        this.currencyTo = currencyTo;
    }

    public Date getTransactionTimestamp() {
        return transactionTimestamp;
    }

    public void setTransactionTimestamp(Date transactionTimestamp) {
        this.transactionTimestamp = transactionTimestamp;
    }

    
}
