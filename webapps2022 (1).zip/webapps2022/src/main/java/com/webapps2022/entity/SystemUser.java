package com.webapps2022.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;
@NamedQuery(name = "findAllSystemUsers", query = "SELECT u FROM SystemUser u")
@NamedQuery(name = "findSystemUserByUsername", query = "SELECT u FROM SystemUser u WHERE u.username=:username")

@Entity
public class SystemUser implements Serializable//Entity for storing user details
{

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    String email;

    @NotNull
    String firstName;

    @NotNull
    String surname;

    @Column(unique = true)
    @NotNull
    String username;

    @NotNull
    String userpassword;

    @NotNull
    @Column(precision = 12, scale = 2)
    BigDecimal balance;

    @NotNull
    String currency;

    
    public SystemUser() {
    }

    public SystemUser(String email, String firstName, String surname, String username, String password, BigDecimal balance, String currency) {
        this.email = email;
        this.firstName = firstName;
        this.surname = surname;
        this.username = username;
        this.userpassword = password;
        this.balance = balance;
        this.currency = currency;
       
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance.setScale(2, RoundingMode.FLOOR);
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    
   
}
